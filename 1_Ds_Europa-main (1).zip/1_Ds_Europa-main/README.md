#Trabalho de Logica
Contruir uma página de um site no VS CODE.
